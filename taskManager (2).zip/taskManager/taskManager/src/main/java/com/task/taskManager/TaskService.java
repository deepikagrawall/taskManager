package com.task.taskManager;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

@Service
public class TaskService {
    @Autowired
    private TaskRepository taskRepository;
    
    @Autowired
    private UserRepository userRepository;

    public Task addTask(Task task, String timezone) {
        AppUser assignedUser = task.getAssignedTo();  // Changed from 'User' to 'AppUser'

        // Convert dueDate to UTC
        ZoneId zoneId = ZoneId.of(timezone != null ? timezone : assignedUser.getTimezone());
        ZonedDateTime zonedDateTime = ZonedDateTime.of(task.getDueDate(), zoneId);
        task.setDueDate(zonedDateTime.withZoneSameInstant(ZoneId.of("UTC")).toLocalDateTime());

        return taskRepository.save(task);
    }
    
    public Task createTask(Task task) {
        return taskRepository.save(task);
    }
    
    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }
    
    public Task getTaskById(Long id) {
        return taskRepository.findById(id)
        		.orElseThrow(() -> new TaskNotFoundException("Task with ID " + id + " not found"));
        
    }
    
    public Task updateTask(Long id, Task taskDetails) {
        Task task = getTaskById(id);
        task.setTitle(taskDetails.getTitle());
        task.setDescription(taskDetails.getDescription());
        task.setStatus(taskDetails.getStatus());
        return taskRepository.save(task);
    }
    
    public void deleteTask(Long id) {
        Task task = getTaskById(id);
        taskRepository.delete(task);
    }
    public Page<Task> getTasks(Task.TaskStatus status, AppUser assignedTo, String title, Pageable pageable) {
        if (status != null && assignedTo != null && title != null) {
            return taskRepository.findByStatusAndAssignedToAndTitleContaining(status, assignedTo, title, pageable);
        } else if (status != null && assignedTo != null) {
            return taskRepository.findByStatusAndAssignedTo(status, assignedTo, pageable);
        } else if (status != null) {
            return taskRepository.findByStatus(status, pageable);
        } else if (assignedTo != null) {
            return taskRepository.findByAssignedTo(assignedTo, pageable);
        } else {
            return taskRepository.findAll(pageable);
        }
    }
    
}
