package com.task.taskManager;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TaskRepository extends JpaRepository<Task, Long> {

    Page<Task> findByStatus(Task.TaskStatus status, Pageable pageable);

    Page<Task> findByAssignedTo(AppUser assignedTo, Pageable pageable);

    Page<Task> findByStatusAndAssignedTo(Task.TaskStatus status, AppUser assignedTo, Pageable pageable);

    // Optional: if you want to filter by both status and user
    Page<Task> findByStatusAndAssignedToAndTitleContaining(Task.TaskStatus status, AppUser assignedTo, String title,Pageable  pageable);

}
