package com.task.taskManager;

import org.springframework.web.bind.annotation.GetMapping;

public class IndexController {

	@GetMapping("/")
    public String index() {
        return "index";  // This maps to /WEB-INF/jsp/index.jsp
	
}
}
