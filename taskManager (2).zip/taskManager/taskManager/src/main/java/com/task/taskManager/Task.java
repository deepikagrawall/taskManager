package com.task.taskManager;

import java.time.LocalDateTime;

import org.apache.catalina.User;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;

@jakarta.persistence.Entity
public class Task {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    
	    @NotBlank(message = "Title is mandatory")
	    private String title;
	    
	    private String description;
	    
	    @Enumerated(EnumType.STRING)
	    private TaskStatus status;
	    
	    @Column(nullable = false, updatable = false)
	    @CreationTimestamp
	    private LocalDateTime createdAt;
	    
	    @Column(nullable = false)
	    @UpdateTimestamp
	    private LocalDateTime updatedAt;
	    
	    @Column(nullable = false)
	    private LocalDateTime dueDate;
	    
	   
	    @ManyToOne
	    @JoinColumn(name = "assigned_to", nullable = false)
	    private AppUser assignedTo;
	    
	    
	    
	    
	    public LocalDateTime getDueDate() {
			return dueDate;
		}




		public void setDueDate(LocalDateTime dueDate) {
			this.dueDate = dueDate;
		}




		public AppUser getAssignedTo() {
			return assignedTo;
		}




		public void setAssignedTo(AppUser assignedTo) {
			this.assignedTo = assignedTo;
		}




		public Long getId() {
			return id;
		}




		public void setId(Long id) {
			this.id = id;
		}




		public String getTitle() {
			return title;
		}




		public void setTitle(String title) {
			this.title = title;
		}




		public String getDescription() {
			return description;
		}




		public void setDescription(String description) {
			this.description = description;
		}




		public TaskStatus getStatus() {
			return status;
		}




		public void setStatus(TaskStatus status) {
			this.status = status;
		}




		public LocalDateTime getCreatedAt() {
			return createdAt;
		}




		public void setCreatedAt(LocalDateTime createdAt) {
			this.createdAt = createdAt;
		}




		public LocalDateTime getUpdatedAt() {
			return updatedAt;
		}




		public void setUpdatedAt(LocalDateTime updatedAt) {
			this.updatedAt = updatedAt;
		}




		


		public enum TaskStatus {
	        PENDING,
	        IN_PROGRESS,
	        COMPLETED
	    }

	}


